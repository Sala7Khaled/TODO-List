package adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sala7khaled.todo_auth.R;

import java.util.ArrayList;

import models.ListItem;
import view_holders.ViewHolder;

public class MyAdapter extends RecyclerView.Adapter<ViewHolder> {
    private Context context;
    private ArrayList<ListItem> listItemsArrayList;
    private CallBack callBack;


    public MyAdapter(Context context) {
        this.context = context;
    }

    public MyAdapter(Context context, ArrayList<ListItem> listItemArrayList, CallBack callBack) {
        this.context = context;
        this.listItemsArrayList = listItemArrayList;
        this.callBack = callBack;
    }

    public void addItem(ListItem item) {
        listItemsArrayList.add(item);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int view_type) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.list_item, viewGroup, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, @SuppressLint("RecyclerView") final int position) {

        final String txt = ListItem.getTodo_text();
        final String dsc = ListItem.getDesc_text();

        viewHolder.title.setText(ListItem.getTodo_text());

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callBack.onItemClick(position, txt, dsc);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItemsArrayList.size();
    }

    public interface CallBack {
        void onItemClick(int position, String txt, String desc);
    }
}
