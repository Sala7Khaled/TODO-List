package com.sala7khaled.todo_auth;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;

import android.os.Parcelable;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import adapters.MyAdapter;
import models.ListItem;
import models.Users;

public class MainActivity extends AppCompatActivity {

    Button add_Btn, ok_Btn, cancel_Btn, logout_Btn;
    EditText todo_EditText;
    EditText desc_EditText;
    Dialog dialog;
    CheckBox checkBox;

    RecyclerView recyclerView;
    ArrayList<ListItem> listItemArrayList = new ArrayList<ListItem>();
    MyAdapter myAdapter;

    DatabaseReference myDatabase;
    FirebaseAuth myAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDatabase = FirebaseDatabase.getInstance().getReference();

        initializeComponents();

        setListeners();
    }

    private void initializeComponents() {
        myAuth = FirebaseAuth.getInstance();

        add_Btn = (Button) findViewById(R.id.todo_add_Btn);
        logout_Btn = (Button) findViewById(R.id.logout_Btn);
        checkBox = (CheckBox) findViewById(R.id.checkBox);

        myAdapter = new MyAdapter(MainActivity.this, listItemArrayList, new MyAdapter.CallBack() {
            @Override
            public void onItemClick(int position, String txt, String dsc) {
                Intent itemIntent = new Intent(MainActivity.this, ItemActivity.class);
                //ListItem listItem = listItemArrayList.get(position);
                itemIntent.putExtra("title", txt);
                itemIntent.putExtra("desc", dsc);
                startActivity(itemIntent);
            }
        });

        recyclerView = findViewById(R.id.RecView);

        // Liner
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false));
        // Gird
        // recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this,3));
        recyclerView.setAdapter(myAdapter);

    }

    private void setListeners() {

        add_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog = new Dialog(MainActivity.this);

                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                //dialog.requestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);
                dialog.setContentView(R.layout.custom_dialog);

                todo_EditText = dialog.findViewById(R.id.todo_EditText);
                desc_EditText = dialog.findViewById(R.id.desc_EditText);
                ok_Btn = dialog.findViewById(R.id.ok_Btn);
                cancel_Btn = dialog.findViewById(R.id.cancel_Btn);

                dialog.getWindow().setLayout(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT);
                dialog.setCancelable(false);


                ok_Btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String todo_text = todo_EditText.getText().toString().trim();
                        String desc_text = desc_EditText.getText().toString().trim();

                        if (todo_text.length() != 0 && desc_text.length() != 0) {

                            ListItem listItem = new ListItem(todo_text, desc_text, false);

                            listItemArrayList.add(listItem);

                            FirebaseUser firebaseUser = myAuth.getCurrentUser();
                            String userUid = firebaseUser.getUid();


                            myDatabase.child("Tasks").child(userUid).setValue(listItem);

                            dialog.cancel();
                        } else if (todo_EditText.getText().toString().length() != 0) {
                            Toast.makeText(MainActivity.this, "Please add description!", Toast.LENGTH_SHORT).show();
                        } else if (desc_EditText.getText().toString().length() != 0) {
                            Toast.makeText(MainActivity.this, "Whoops you forgot the Title!", Toast.LENGTH_SHORT).show();
                        } else {
                            dialog.cancel();
                            Toast.makeText(MainActivity.this, "Nothing added!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                cancel_Btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });

                dialog.show();
            }
        });

        logout_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseUser currentUser = myAuth.getCurrentUser();
                myAuth.signOut();

                Toast.makeText(MainActivity.this, "Goodbye " + currentUser.getEmail(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();

            }
        });

    }
}