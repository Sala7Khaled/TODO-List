package models;

public class ListItem
{
    private long id;
    private static String todo_text;
    private static String desc_text;
    private static Boolean checkbox;

    public ListItem(String todo_text, String desc_text ,Boolean checkbox) {
        ListItem.todo_text = todo_text;
        ListItem.desc_text = desc_text;
        ListItem.checkbox = checkbox;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public static String getTodo_text() {
        return todo_text;
    }

    public void setTodo_text(String todo_text) {
        ListItem.todo_text = todo_text;
    }

    public static Boolean getCheckbox() {
        return checkbox;
    }

    public void setCheckbox(Boolean checkbox) {
        ListItem.checkbox = checkbox;
    }

    public static String getDesc_text() {
        return desc_text;
    }

    public void setDesc_text(String desc_text) {
        ListItem.desc_text = desc_text;
    }
}
